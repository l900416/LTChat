//
//  LTIMRosterTableViewController.h
//  LTIM
//
//  Created by 梁通 on 2017/9/21.
//  Copyright © 2017年 Personal. All rights reserved.
//

#import <UIKit/UIKit.h>

/*花名册*/
@interface LTIMRosterTableViewController : UITableViewController

@end
