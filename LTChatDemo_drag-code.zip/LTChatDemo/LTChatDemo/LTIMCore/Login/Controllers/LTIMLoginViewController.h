//
//  LTIMLoginViewController.h
//  LTIM
//
//  Created by 梁通 on 2017/9/22.
//  Copyright © 2017年 Personal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LTIMLoginViewController : UIViewController

@end
